package com.eduapp.englishlearning

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val state = AppState(applicationContext)
        val words = VocabRepo.load(this)
        setContent { AppTheme { App(state, words) } }
    }
}

@Composable
fun App(state: AppState, words: List<Word>) {
    var screen by rememberSaveable { mutableStateOf(if (state.loggedIn) "home" else "login") }
    BackHandler(enabled = screen == "vocab" || screen == "profile") { screen = "home" }

    when (screen) {
        "login" -> LoginScreen(state) { screen = "home" }
        "home" -> HomeScreen(state, onVocab = { screen = "vocab" }, onProfile = { screen = "profile" })
        "vocab" -> VocabScreen(state, words) { screen = "home" }
        "profile" -> ProfileScreen(state) { screen = "home" }
    }
}
