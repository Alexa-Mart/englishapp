package com.eduapp.englishlearning

import android.content.Context
import org.json.JSONArray

data class Word(val id: Int, val category: String, val english: String, val bangla: String)

data class Question(val word: Word, val options: List<String>)

object VocabRepo {
    fun load(ctx: Context): List<Word> {
        val text = ctx.assets.open("vocab.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONArray(text)
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Word(o.getInt("id"), o.getString("c"), o.getString("e"), o.getString("b"))
        }
    }
}

fun makeQuestion(word: Word, all: List<Word>): Question {
    // একই বাংলা অর্থের অন্য শব্দ distractor হিসেবে আসবে না
    val distractors = all
        .filter { it.id != word.id && it.bangla != word.bangla && !it.english.equals(word.english, true) }
        .shuffled()
        .take(3)
        .map { it.english }
    return Question(word, (distractors + word.english).shuffled())
}
