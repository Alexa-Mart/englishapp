package com.eduapp.englishlearning

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B2A8F)
val Blue = Color(0xFF1E4FD8)
val Bg = Color(0xFFEEF1FB)
val Ink = Color(0xFF0F1A5C)
val Green = Color(0xFF16A34A)
val Gold = Color(0xFFFACC15)
val Red = Color(0xFFDC2626)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White,
            secondary = Navy, background = Bg, surface = Color.White
        ),
        content = content
    )
}
