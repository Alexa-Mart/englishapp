package com.eduapp.englishlearning

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun VocabScreen(state: AppState, words: List<Word>, onBack: () -> Unit) {
    // শব্দগুলো এলোমেলো ক্রমে আসবে; সব শেষ হলে আবার shuffle হবে
    val queue = remember { ArrayDeque<Word>() }
    fun nextQuestion(): Question {
        if (queue.isEmpty()) queue.addAll(words.shuffled())
        return makeQuestion(queue.removeFirst(), words)
    }

    var q by remember { mutableStateOf(nextQuestion()) }
    var wrongPicks by remember(q) { mutableStateOf(setOf<String>()) }
    var solved by remember(q) { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) { delay(1000); now = System.currentTimeMillis() }
    }
    LaunchedEffect(solved) {
        if (solved) { delay(800); q = nextQuestion() }
    }

    val left = state.unlockUntil - now

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Navy).statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("Vocabulary", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (left > 0) Text("Access left: ${fmtTime(left)}", color = Color(0xFFCFE0FF), fontSize = 12.sp)
            }
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF)).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(fmtStars(state.stars), color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(6.dp))
        }

        Column(
            Modifier.weight(1f).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // বাংলা শব্দ কার্ড
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF0A2FB5), Color(0xFF2563EB))))
                    .padding(vertical = 26.dp, horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(q.word.category, color = Color(0xFFCFE0FF), fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Text(q.word.bangla, color = Color.White, fontSize = 32.sp,
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Text("সঠিক ইংরেজি শব্দটি বেছে নিন", color = Gold, fontSize = 14.sp)
            }

            Text(
                when {
                    solved -> "✅ সঠিক! +1 Star"
                    wrongPicks.isNotEmpty() -> "❌ ভুল! -0.25 Star — আবার চেষ্টা করুন"
                    else -> " "
                },
                color = if (solved) Green else Red, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )

            q.options.forEach { opt ->
                val isRight = solved && opt.equals(q.word.english, true)
                val isWrong = opt in wrongPicks
                val bg by animateColorAsState(
                    when { isRight -> Color(0xFFBBF7D0); isWrong -> Color(0xFFFECACA); else -> Color.White },
                    label = "opt"
                )
                OutlinedButton(
                    onClick = {
                        if (solved || isWrong || left <= 0) return@OutlinedButton
                        if (opt == q.word.english) {
                            state.recordCorrect(q.word.id); solved = true
                        } else {
                            wrongPicks = wrongPicks + opt; state.recordWrong()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = bg, contentColor = Ink),
                    border = BorderStroke(1.5.dp, if (isRight) Green else if (isWrong) Red else Color(0xFFB8C4EE))
                ) { Text(opt, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
            }
        }

        // Footer: Skip
        Box(Modifier.fillMaxWidth().background(Color.White).navigationBarsPadding().padding(12.dp)) {
            Button(
                onClick = { if (!solved) q = nextQuestion() },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("Skip", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
            }
        }
    }

    if (left <= 0) {
        AlertDialog(
            onDismissRequest = onBack,
            title = { Text("সময় শেষ") },
            text = { Text("১২ ঘণ্টার Vocabulary access শেষ হয়েছে। আবার ঢুকতে ${fmtStars(VOCAB_COST)} Star লাগবে।") },
            confirmButton = { TextButton(onClick = onBack) { Text("OK") } }
        )
    }
}

private fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}
