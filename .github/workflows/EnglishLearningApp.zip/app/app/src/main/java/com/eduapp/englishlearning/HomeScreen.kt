package com.eduapp.englishlearning

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(state: AppState, onVocab: () -> Unit, onProfile: () -> Unit) {
    val ctx = LocalContext.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var dialog by remember { mutableStateOf<String?>(null) }

    fun openVocab() {
        dialog = when {
            state.isVocabUnlocked() -> { onVocab(); null }
            state.stars >= VOCAB_COST -> "confirm"
            else -> "low"
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    Modifier.fillMaxWidth().background(Navy).padding(24.dp)
                ) {
                    Text(state.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(state.contact, color = Color(0xFFCFE0FF), fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("${fmtStars(state.stars)} Star", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
                NavigationDrawerItem(
                    label = { Text("Home") }, selected = true,
                    icon = { Icon(Icons.Filled.Home, null) },
                    onClick = { scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Profile") }, selected = false,
                    icon = { Icon(Icons.Filled.Person, null) },
                    onClick = { scope.launch { drawer.close() }; onProfile() },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }
    ) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            // Top bar
            Row(
                Modifier.fillMaxWidth().background(Navy).statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Menu, "Menu", tint = Color.White,
                    modifier = Modifier.size(30.dp).clickable { scope.launch { drawer.open() } })
                Text("English Learning", color = Color.White, fontSize = 24.sp,
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.Notifications, "Notifications", tint = Color.White,
                    modifier = Modifier.size(30.dp).clickable { dialog = "bell" })
            }

            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp).navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(2.dp))
                Banner()

                Text("Your Learning Progress", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                val pct = state.lessonsDone.toFloat() / TOTAL_LESSONS
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(pct, Modifier.size(118.dp))
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFFDCE3FA)).padding(16.dp)
                    ) {
                        StatRow(Icons.Filled.MenuBook, Blue, "Completed Lessons", "${state.lessonsDone} / $TOTAL_LESSONS")
                        HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Color(0xFFB8C4EE))
                        StatRow(Icons.Filled.EmojiEvents, Color(0xFFF59E0B), "Total Courses", "5")
                    }
                }

                Text("Quick Access", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                val soon = { Toast.makeText(ctx, "Coming soon", Toast.LENGTH_SHORT).show() }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Vocabulary", Color(0xFFBBD7FA), Color(0xFF1E4FD8), Ink, Modifier.weight(1f), { openVocab() }) {
                        Icon(Icons.Filled.MenuBook, null, tint = Color(0xFF1E4FD8), modifier = Modifier.size(46.dp))
                    }
                    Tile("Grammar", Color(0xFFBDEFD0), Green, Color(0xFF14532D), Modifier.weight(1f), soon) {
                        Text("A", color = Color(0xFF15803D), fontSize = 44.sp, fontWeight = FontWeight.Black)
                    }
                    Tile("Punctuation", Color(0xFFD3C4F8), Color(0xFF4C1D95), Color(0xFF2E1065), Modifier.weight(1f), soon) {
                        Icon(Icons.Filled.Edit, null, tint = Color(0xFF312E81), modifier = Modifier.size(46.dp))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Article", Color(0xFFFFD9B8), Color(0xFFEA580C), Color(0xFF7C2D12), Modifier.weight(1f), soon) {
                        Icon(Icons.Filled.Description, null, tint = Color(0xFFEA580C), modifier = Modifier.size(46.dp))
                    }
                    Tile("Translation", Color(0xFFB3E0FB), Blue, Ink, Modifier.weight(1f), soon) {
                        Icon(Icons.Filled.Translate, null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(46.dp))
                    }
                    Tile("Practice Test", Color(0xFFDDF4B0), Green, Color(0xFF14532D), Modifier.weight(1f), soon) {
                        Icon(Icons.Filled.BarChart, null, tint = Color(0xFF15803D), modifier = Modifier.size(46.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    when (dialog) {
        "confirm" -> AlertDialog(
            onDismissRequest = { dialog = null },
            icon = { Icon(Icons.Filled.Star, null, tint = Gold) },
            title = { Text("Unlock Vocabulary") },
            text = { Text("${fmtStars(VOCAB_COST)} Star দিয়ে ১২ ঘণ্টার জন্য Vocabulary আনলক হবে।\nআপনার বর্তমান Star: ${fmtStars(state.stars)}") },
            confirmButton = {
                Button(onClick = {
                    dialog = null
                    if (state.unlockVocabulary()) onVocab()
                }) { Text("Unlock (-50 Star)") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
        "low" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Star পর্যাপ্ত নয়") },
            text = { Text("Vocabulary খুলতে ${fmtStars(VOCAB_COST)} Star লাগবে। আপনার আছে ${fmtStars(state.stars)} Star।") },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("OK") } }
        )
        "bell" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Notifications") },
            text = { Text("🎁 Login bonus: 100 Star যুক্ত হয়েছে।\n⭐ বর্তমান Star: ${fmtStars(state.stars)}") },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun Banner() {
    Box(
        Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF0A2FB5), Color(0xFF2563EB))))
    ) {
        Column(Modifier.padding(start = 20.dp, top = 16.dp)) {
            Text("Improve Your", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("English Skills", color = Gold, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text("Small Steps...\nBig Success...", color = Color.White, fontSize = 17.sp,
                fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold, lineHeight = 21.sp)
        }
        BannerArt(Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).size(width = 150.dp, height = 130.dp))
    }
}

@Composable
private fun BannerArt(modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(Color(0xFFF5F7FF), Offset(w * 0.06f, h * 0.80f), Size(w * 0.88f, h * 0.15f), CornerRadius(10f))
        drawRoundRect(Color(0xFFFFA726), Offset(w * 0.02f, h * 0.63f), Size(w * 0.84f, h * 0.16f), CornerRadius(10f))
        drawRoundRect(Color(0xFF42A5F5), Offset(w * 0.12f, h * 0.48f), Size(w * 0.72f, h * 0.14f), CornerRadius(10f))
        drawRoundRect(Color(0xFF1B2250), Offset(w * 0.27f, h * 0.30f), Size(w * 0.46f, h * 0.16f), CornerRadius(14f))
        val cap = Path().apply {
            moveTo(w * 0.5f, h * 0.06f); lineTo(w * 0.96f, h * 0.24f)
            lineTo(w * 0.5f, h * 0.40f); lineTo(w * 0.04f, h * 0.24f); close()
        }
        drawPath(cap, Color(0xFF232C66))
        drawLine(Gold, Offset(w * 0.5f, h * 0.24f), Offset(w * 0.9f, h * 0.30f), strokeWidth = 5f)
        drawLine(Gold, Offset(w * 0.9f, h * 0.30f), Offset(w * 0.9f, h * 0.52f), strokeWidth = 8f, cap = StrokeCap.Round)
    }
}

@Composable
private fun ProgressRing(progress: Float, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val stroke = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Color(0xFFCBD5D1), 0f, 360f, false, style = Stroke(width = 16.dp.toPx()))
            drawArc(Color(0xFF16B34A), -90f, 360f * progress, false, style = stroke)
        }
        Text("${(progress * 100).toInt()}%", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun StatRow(icon: ImageVector, tint: Color, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, color = Ink, fontSize = 14.sp)
            Text(value, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun Tile(
    label: String, bg: Color, @Suppress("UNUSED_PARAMETER") accent: Color, textColor: Color,
    modifier: Modifier, onClick: () -> Unit, icon: @Composable () -> Unit
) {
    Column(
        modifier.height(104.dp).clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        icon()
        Spacer(Modifier.height(4.dp))
        Text(label, color = textColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
