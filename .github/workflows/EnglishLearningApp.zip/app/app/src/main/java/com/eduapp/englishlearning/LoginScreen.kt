package com.eduapp.englishlearning

import android.util.Patterns
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val levels = listOf(
    "Primary (Class 1-5)", "Class 6-8", "SSC / Class 9-10", "HSC / Class 11-12",
    "Diploma", "Honours / Degree", "Masters", "Other"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(state: AppState, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var edu by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy, Blue)))
            .statusBarsPadding()
    ) {
        Column(
            Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.MenuBook, null, tint = Gold, modifier = Modifier.size(52.dp))
            Spacer(Modifier.height(8.dp))
            Text("English Learning", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Login & get 100 Star bonus", color = Color(0xFFCFE0FF), fontSize = 14.sp)
        }

        Column(
            Modifier.fillMaxSize()
                .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                .background(Bg)
                .verticalScroll(rememberScrollState())
                .padding(22.dp)
                .navigationBarsPadding()
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("নাম (Name)") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
            )

            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = edu, onValueChange = {}, readOnly = true,
                    label = { Text("শিক্ষাগত অবস্থান (Education)") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    levels.forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { edu = it; expanded = false })
                    }
                }
            }

            OutlinedTextField(
                value = contact, onValueChange = { contact = it.trim() },
                label = { Text("Mobile number / Email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
            )

            OutlinedTextField(
                value = age, onValueChange = { if (it.length <= 3 && it.all(Char::isDigit)) age = it },
                label = { Text("বয়স (Age)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
            )

            Text("Gender", fontWeight = FontWeight.SemiBold, color = Ink)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Male", "Female").forEach { g ->
                    FilterChip(
                        selected = gender == g, onClick = { gender = g },
                        label = { Text(g, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) }
                    )
                }
            }

            error?.let { Text(it, color = Red, fontSize = 13.sp) }

            Button(
                onClick = {
                    val isPhone = contact.filter { it.isDigit() }.length in 10..14 &&
                        contact.all { it.isDigit() || it == '+' || it == '-' || it == ' ' }
                    val isMail = Patterns.EMAIL_ADDRESS.matcher(contact).matches()
                    val ageNum = age.toIntOrNull()
                    error = when {
                        name.isBlank() -> "নাম লিখুন"
                        edu.isEmpty() -> "শিক্ষাগত অবস্থান নির্বাচন করুন"
                        !isPhone && !isMail -> "সঠিক মোবাইল নম্বর বা ইমেইল দিন"
                        ageNum == null || ageNum !in 3..100 -> "সঠিক বয়স দিন (৩-১০০)"
                        gender.isEmpty() -> "Male / Female নির্বাচন করুন"
                        else -> null
                    }
                    if (error == null) {
                        state.register(name.trim(), edu, contact, age, gender)
                        onDone()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Login", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
