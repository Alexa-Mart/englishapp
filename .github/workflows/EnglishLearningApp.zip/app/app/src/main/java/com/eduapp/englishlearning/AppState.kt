package com.eduapp.englishlearning

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

const val WELCOME_BONUS = 100f
const val VOCAB_COST = 50f
const val VOCAB_ACCESS_MS = 12L * 60 * 60 * 1000
const val CORRECT_POINT = 1f
const val WRONG_PENALTY = 0.25f
const val WORDS_PER_LESSON = 25
const val TOTAL_LESSONS = 20

/** সব ডাটা ফোনের লোকাল স্টোরেজে (SharedPreferences) জমা থাকে। */
class AppState(context: Context) {
    private val p = context.getSharedPreferences("edu_learning", Context.MODE_PRIVATE)

    var loggedIn by mutableStateOf(p.getBoolean("loggedIn", false)); private set
    var name by mutableStateOf(p.getString("name", "") ?: ""); private set
    var education by mutableStateOf(p.getString("education", "") ?: ""); private set
    var contact by mutableStateOf(p.getString("contact", "") ?: ""); private set
    var age by mutableStateOf(p.getString("age", "") ?: ""); private set
    var gender by mutableStateOf(p.getString("gender", "") ?: ""); private set
    var stars by mutableStateOf(p.getFloat("stars", 0f)); private set
    var unlockUntil by mutableLongStateOf(p.getLong("unlockUntil", 0L)); private set
    var correctCount by mutableIntStateOf(p.getInt("correctCount", 0)); private set
    var wrongCount by mutableIntStateOf(p.getInt("wrongCount", 0)); private set
    var mastered by mutableStateOf(
        (p.getStringSet("mastered", emptySet()) ?: emptySet()).toSet()
    ); private set

    val lessonsDone: Int get() = minOf(TOTAL_LESSONS, mastered.size / WORDS_PER_LESSON)

    fun register(name: String, edu: String, contact: String, age: String, gender: String) {
        this.name = name; education = edu; this.contact = contact
        this.age = age; this.gender = gender
        loggedIn = true
        stars = WELCOME_BONUS // লগিন বোনাস
        p.edit()
            .putBoolean("loggedIn", true).putString("name", name)
            .putString("education", edu).putString("contact", contact)
            .putString("age", age).putString("gender", gender)
            .putFloat("stars", stars).apply()
    }

    fun isVocabUnlocked(now: Long = System.currentTimeMillis()) = unlockUntil > now

    /** ৫০ স্টার কেটে ১২ ঘণ্টার জন্য Vocabulary আনলক করে। */
    fun unlockVocabulary(): Boolean {
        if (stars < VOCAB_COST) return false
        stars -= VOCAB_COST
        unlockUntil = System.currentTimeMillis() + VOCAB_ACCESS_MS
        p.edit().putFloat("stars", stars).putLong("unlockUntil", unlockUntil).apply()
        return true
    }

    fun recordCorrect(wordId: Int) {
        stars += CORRECT_POINT
        correctCount += 1
        mastered = mastered + wordId.toString()
        p.edit().putFloat("stars", stars).putInt("correctCount", correctCount)
            .putStringSet("mastered", mastered).apply()
    }

    fun recordWrong() {
        stars = maxOf(0f, stars - WRONG_PENALTY)
        wrongCount += 1
        p.edit().putFloat("stars", stars).putInt("wrongCount", wrongCount).apply()
    }
}

fun fmtStars(v: Float): String =
    if (v % 1f == 0f) v.toInt().toString()
    else String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
